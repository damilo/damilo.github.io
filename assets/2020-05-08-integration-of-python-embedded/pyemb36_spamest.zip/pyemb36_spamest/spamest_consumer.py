import sys
from sklearn.neural_network import MLPClassifier

try:
    import cPickle as pickle
except ModuleNotFoundError:
    import pickle


def vectorize_dataset (X, y):
    vectorizer = CountVectorizer (
        stop_words = 'english',
        max_features = 4096,
        binary = True
        )
    X_v = vectorizer.fit_transform (X).toarray ().astype ('f4')
    y_v = np.array (y).astype ('i4')

    return X_v, y_v


def load_vectorizer (vecFilePath):
    with open (vecFilePath, 'rb') as fileObj:
        vec = pickle.load (fileObj)
    return vec


def load_estimator (mlmFilePath):
    with open (mlmFilePath, 'rb') as fileObj:
        est = pickle.load (fileObj)
    return est


def predict (est, X):
    y_pred = est.predict (X)
    return y_pred


def load_predict (mlmFilePath, vecFilePath, sample):
    vec = load_vectorizer (vecFilePath)
    X = vec.transform ([sample]).toarray ().astype ('f4')
    return predict (load_estimator (mlmFilePath), X)


def main ():
    if len (sys.argv) != 4:
        return
    mlmFilePath = sys.argv[1]
    vecFilePath = sys.argv[2]
    sample = sys.argv[3]

    clf = load_estimator (mlmFilePath)
    print ("+ model loaded")
    print (clf.get_params ())
    vec = load_vectorizer (vecFilePath)
    print ("+ vectorizer loaded")
    print (vec.get_params ())
    y_pred = predict (clf, vec.transform ([sample]).toarray ().astype ('f4'))
    print ("+ prediction:", "ham" if y_pred[0] == 0 else "spam")

    return

if __name__ == '__main__':
    main ()