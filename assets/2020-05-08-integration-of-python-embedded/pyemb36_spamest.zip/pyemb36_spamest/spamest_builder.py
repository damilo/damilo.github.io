import os
import csv
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import confusion_matrix

try:
    import cPickle as pickle
except ModuleNotFoundError:
    import pickle

RND_STATE = 42


def load_dataset (dsFilePath):
    header = True
    X_raw = []
    y_raw = []
    with open (dsFilePath, 'r') as csvFile:
        reader = csv.reader (csvFile, delimiter=',')
        for row in reader:
            # jump over header
            if (header):
                header = False
                continue
            # col "text"
            X_raw.append (row[0])
            # col "spam"
            y_raw.append (row[1])

    return X_raw, y_raw


def vectorize_dataset (X, y):
    vectorizer = CountVectorizer (
        stop_words = 'english',
        max_features = 4096,
        binary = True
        )
    X_v = vectorizer.fit_transform (X).toarray ().astype ('f4')
    y_v = np.array (y).astype ('i4')

    return X_v, y_v


def save_vectorizer (vec):
    vecFile = 'spamest_vectorizer' + '.vec'
    with open (vecFile, 'wb') as fileObj:
        pickle.dump (vec, fileObj, -1)
        vecFilePath = fileObj.name
    return vecFilePath


def save_estimator (est):
    mlmFile = 'spamest_model' + '.mlm'
    with open (mlmFile, 'wb') as fileObj:
        pickle.dump (est, fileObj, -1)
        mlmFilePath = fileObj.name
    return mlmFilePath


def predict (est, X):
    y_pred = est.predict (X)
    return y_pred


if __name__ == '__main__':
    dsFilePath = os.path.join ('emails.csv')
    X_raw, y_raw = load_dataset (dsFilePath)
    m = len (X_raw)
    print ('number of samples:', m)
    print ('number of classes:', len (set (y_raw)), set (y_raw))

    #X, y = vectorize_dataset (X_raw, y_raw)
    vectorizer = CountVectorizer (
        stop_words = 'english',
        max_features = 4096,
        binary = True
    )
    X = vectorizer.fit_transform (X_raw).toarray ().astype ('f4')
    y = np.array (y_raw).astype ('i4')
    print ('+ shape of')
    print ('|- vectorized features:', X.shape)
    print ('|- classes:', y.shape)

    X_train, X_test, y_train, y_test = train_test_split (X, y, test_size = 0.2, shuffle = True, random_state = RND_STATE)
    print ('+ number of samples:')
    print ('|- training:', X_train.shape[0])
    print ('|- test:', X_test.shape[0])

    clf = MLPClassifier (
        hidden_layer_sizes = (100, 2),
        activation = 'relu',
        solver = 'sgd',
        batch_size = 40,
        shuffle = False,
        early_stopping = True,
        max_iter = 50,
        validation_fraction = 0.2,
        random_state = 42,
        verbose = True
        )
    clf.fit (X_train, y_train)

    y_pred = predict (clf, X_test)
    tn, fp, fn, tp = confusion_matrix (y_test, y_pred).ravel ()
    print (tn, fp, fn, tp)

    mlmFilePath = save_estimator (clf)
    print ("+ estimator saved, path = ", mlmFilePath)

    vecFilePath = save_vectorizer (vectorizer)
    print ("+ vectorizer saved, path = ", vecFilePath)