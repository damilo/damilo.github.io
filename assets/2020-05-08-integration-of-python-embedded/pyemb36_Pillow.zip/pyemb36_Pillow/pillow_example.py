import sys
import os
from PIL import Image

def main ():
    if len (sys.argv) != 2:
        print ("Please provide image file as argument.\nProgram will exit now...")
        return
    
    imgFilePath = sys.argv[1]
    with Image.open (imgFilePath) as img:
        img = img.convert ("L")
        fileName, fileExt = os.path.splitext (imgFilePath)
        img.save (fileName + "_bw" + fileExt)
    
    return


if __name__ == "__main__":
    main ()